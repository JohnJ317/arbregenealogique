// Importation de la connexion à la base de données
const connection = require('./db');

class Parents {
  constructor(id_enfant, id_pere, id_mere) {
    this.id_enfant = id_enfant;
    this.id_pere = id_pere;
    this.id_mere = id_mere;
  }

 // Méthode pour ajouter un enregistrement dans la table parents
 static ajouterParent(id_enfant, id_pere, id_mere) {
    // Créer un nouvel objet Parents avec les valeurs passées en paramètres
    const parent = new Parents(id_enfant, id_pere, id_mere);

    // Utiliser la connexion à la base de données pour exécuter une requête d'insertion
    connection.query('INSERT INTO parents (id_enfant, id_pere, id_mere) VALUES (?, ?, ?)', [parent.id_enfant, parent.id_pere, parent.id_mere], (err, result) => {
      if (err) {
        console.error(err);
        return;
      }
      console.log('Nouveau parent ajouté avec succès !');
    });
  }

  // Méthode pour mettre à jour les informations du père ou de la mère dans la table parents
  static modifierParent(id_enfant, id_pere, id_mere) {
    // Utiliser la connexion à la base de données pour exécuter une requête de mise à jour
    connection.query('UPDATE parents SET id_pere = ?, id_mere = ? WHERE id_enfant = ?', [id_pere, id_mere, id_enfant], (err, result) => {
      if (err) {
        console.error(err);
        return;
      }
      console.log('Parent mis à jour avec succès !');
    });
  }

  static deleteParent(id_enfant) {
    // Utiliser la connexion à la base de données pour exécuter une requête de mise à jour
    connection.query('DELETE FROM parents  WHERE id_enfant = ?', [id_enfant], (err, result) => {
      if (err) {
        console.error(err);
      }
      console.log('Parent mis à jour avec succès !');
    });
  }

}

module.exports = Parents;
