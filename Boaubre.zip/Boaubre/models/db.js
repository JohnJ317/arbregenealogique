// db.js

const mysql = require('mysql');

// Configuration de la connexion à la base de données
const connection = mysql.createConnection({
  host: '127.0.0.1', // Hôte de la base de données
  user: 'root', // Utilisateur de la base de données
  password: '', // Mot de passe de la base de données
  database: 'famille' // Nom de la base de données
});

// Connexion à la base de données
connection.connect((err) => {
  if (err) {
    console.error('Erreur de connexion à la base de données : ' + err.stack);
    return;
  }
  console.log('Connecté à la base de données MySQL avec l\'identifiant de connexion ' + connection.threadId);
});

// Exportation de la connexion à la base de données pour être utilisée dans d'autres modules
module.exports = connection;
