const { removeAllListeners } = require('./db')
let connection = require('./db')
let moment = require('moment')

class User{

    constructor (row){
        if(typeof row !== 'undefined'){
        this.id=row.id
        this.nom=row.nom
        this.prenoms=row.prenoms
        this.phone=row.phone
        this.email=row.email
        this.password=row.password
        }
    }
    get user_id(){
        return this.row.id
    }
    get user_nom(){
        return this.row.nom
    }
    get user_prenoms(){
        return this.row.prenoms
    }
    get user_phone(){
        return this.row.phone
    }
    get user_email(){
        return this.row.email
    }
    get user_password(){
        return this.row.password
    }
    static exist_email(email,cb){
        connection.query('SELECT * from user where email = ?',email,(err,rows)=>{
            if(err) throw err
            cb(new User(rows[0]))
        })
    }

    static exist_phone(phone,cb){
        connection.query('SELECT * from user where phone = ?',phone,(err,rows)=>{
            if(err) throw err
            cb(new User(rows[0]))
        })
    }

    static inscription(user,cb){
        connection.query('INSERT INTO user SET nom = ?, prenoms = ?, phone = ?, email = ?, password = ?',user,(err,res)=>{
            if(err) throw err
            cb(res)
        })
    }
    static exist_user(email,password,cb){
        connection.query('SELECT * from user where email = "'+email+'" and password ="'+ password+'"',(err,rows)=>{
            if(err) throw err
            cb(new User(rows[0]))
        })
    }
    static update(email,password,cb){
        connection.query('UPDATE user set password ="'+ password+'" where email ="'+email+'"',(err,res)=>{
            if(err) throw err
            cb(res)
        })
    }

   
}

module.exports=User