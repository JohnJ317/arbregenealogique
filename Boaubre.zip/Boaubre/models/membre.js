// Importation de la connexion à la base de données
const connection = require('./db');

class Membre {
  constructor(id, prenoms, nom, date_naissance, date_deces, photo, genre, ) {
    this.id = id;
    this.prenoms = prenoms;
    this.nom = nom;
    this.date_naissance = date_naissance;
    this.date_deces = date_deces;
    this.photo = photo;
    this.genre = genre;
  }

  // Méthodes pour accéder et modifier les propriétés de la classe
  // ... (méthodes existantes pour accéder et modifier les propriétés)

  // Méthode pour créer un membre dans la base de données
  static createMembre(prenoms, nom, date_naissance, date_deces, photo, genre) {
    return new Promise((resolve, reject) => {
      const query = `INSERT INTO membres (prenoms, nom, date_naissance, date_deces, photo, genre) 
                   VALUES (?, ?, ?, ?, ?,?)`;
      const values = [prenoms, nom, date_naissance, date_deces, photo, genre, ];
      connection.query(query, values, (error, results) => {
        if (error) {
          reject(error);
        } else {
          const newMembreId = results.insertId;
          const newMembre = new Membre(newMembreId, prenoms, nom, date_naissance, date_deces, photo, genre);
          resolve(newMembre);
        }
      });
    });
  }

// Méthode pour rechercher un membre par ID dans la base de données
static findMembreById(id) {
  return new Promise((resolve, reject) => {
    const query = 'SELECT * FROM membres WHERE id = ?';
    const values = [id];
    connection.query(query, values, (error, results) => {
      if (error) {
        reject(error);
      } else {
        if (results.length > 0) {
          const membreData = results[0];
          const membre = new Membre(membreData.id, membreData.prenoms, membreData.nom, membreData.date_naissance, membreData.date_deces, membreData.photo, membreData.genre);
          resolve(membre);
        } else {
          resolve(null);
        }
      }
    });
  });
}


  // Méthode pour rechercher des membres par un champ quelconque dans la base de données
  static findMembresByField(fieldName, fieldValue) {
    return new Promise((resolve, reject) => {
      const query = `SELECT * FROM membres WHERE ${fieldName} = ?`;
      const values = [fieldValue];
      connection.query(query, values, (error, results) => {
        if (error) {
          reject(error);
        } else {
          const membres = results.map(membreData => {
            return new Membre(membreData.id, membreData.prenoms, membreData.nom, membreData.date_naissance, membreData.date_deces, membreData.photo, membreData.profession, membreData.genre, membreData.id_generation);
          });
          resolve(membres);
        }
      });
    });
  }
  static findConjoint(membreId,cb) {
     new Promise((resolve, reject) => {
      const query = ` SELECT *,
      CASE
        WHEN id_conjoint1 = ? THEN id_conjoint2
        WHEN id_conjoint2 = ? THEN id_conjoint1
      END AS selectedId
      FROM conjoints
      WHERE (id_conjoint1 = ? OR id_conjoint2 = ?) AND id_conjoint2 !=0`;
      const values = [membreId,membreId,membreId,membreId];
      connection.query(query, values, (error, results) => {
        if (error) {
          reject(error);
        } else {
          const conjoints = results.map(membreData => { 
            return membreData.selectedId
          });
          cb(conjoints);
        }
      });
    });
  }
  static findEnfant(parent1, parent2,cb) {
     new Promise((resolve, reject) => {
        const query = `SELECT id_enfant
                      FROM parents
                      WHERE (id_pere = ? AND id_mere = ?) or (id_pere = ? AND id_mere = ?)`;
        const values = [parent1, parent2,parent2,parent1];
        connection.query(query, values, (error, results) => {
            if (error) {
                reject(error);
            } else {
                const enfants = results.map(enfantData => {
                    return enfantData.id_enfant;
                });
                cb(enfants);
            }
        });
    });
  }

static find(field, cb) {
  const query = "SELECT * FROM membres WHERE nom LIKE " + field + " OR prenoms LIKE " + field + " OR date_naissance LIKE " + field + " OR date_deces LIKE " + field;
  connection.query(query, (err, rows) => {
    if (err) throw err;
    cb(rows);
  });
}
static ajouterConjointsPourEnfants() {
  connection.query(
    'SELECT id_enfant, id_pere, id_mere FROM parents WHERE id_pere IS NOT NULL AND id_mere IS NOT NULL',
    function(err, results) {
      if (err) throw err;

      // Pour chaque enfant ayant un père et une mère, on vérifie si leur couple existe déjà dans la table conjoint
      results.forEach(function(row) {
        const idPere = row.id_pere;
        const idMere = row.id_mere;
        const idsConjoints = [idPere, idMere].sort().join(',');

        connection.query(
          'SELECT * FROM conjoints WHERE id_conjoint1 IN (?, ?) AND id_conjoint2 IN (?, ?)',
          [idPere, idMere, idPere, idMere],
          function(err, results) {
            if (err) throw err;

            // Si leur couple n'existe pas encore dans la table conjoint, on l'ajoute
            if (results.length === 0) {
              connection.query(
                'INSERT INTO conjoints (id_conjoint1, id_conjoint2) VALUES (?, ?)',
                [idPere, idMere],
                function(err, results) {
                  if (err) throw err;
                  
                }
              );
            }
          }
        );
      });
    }
  );
}
static supprimerCouplesSansEnfants() {
  connection.query(
    'SELECT id_conjoint1, id_conjoint2 FROM conjoints',
    function(err, results) {
      if (err) throw err;

      // Pour chaque couple dans la table conjoint, on vérifie s'il a des enfants dans la table parents
      results.forEach(function(row) {
        const idConjoint1 = row.id_conjoint1;
        const idConjoint2 = row.id_conjoint2;

        connection.query(
          'SELECT * FROM parents WHERE (id_pere = ? AND id_mere = ?) OR (id_pere = ? AND id_mere = ?)',
          [idConjoint1, idConjoint2, idConjoint2, idConjoint1],
          function(err, results) {
            if (err) throw err;

            // Si le couple n'a pas d'enfants dans la table parents, on le supprime de la table conjoint
            if (results.length === 0) {
              connection.query(
                'DELETE FROM conjoints WHERE id_conjoint1 = ? AND id_conjoint2 = ?',
                [idConjoint1, idConjoint2],
                function(err, results) {
                  if (err) throw err;
                }
              );
            }
          }
        );
      });
    }
  );
}


  static lastconjoint(cb) {
    new Promise((reject) => {
       const query = 'SELECT id_conjoint1 FROM `conjoints` WHERE id_conjoint2 != 0 ORDER BY id_conjoint1 DESC LIMIT 1'
       connection.query(query, (error, results) => {
           if (error) {
               reject(error);
           } else {
               cb(results[0].id_conjoint1)
           }
       });
   });
 }






   // Méthode pour rechercher tous les membres dans la base de données
   static findMembres(cb) {
     new Promise(( reject) => {
      
      const query = `SELECT m.*, c.id_conjoint1, c.id_conjoint2, c.date_mariage, p.id_enfant, p.id_pere, p.id_mere
      FROM membres m
      LEFT JOIN conjoints c ON m.id = c.id_conjoint1 OR m.id = c.id_conjoint2
      LEFT JOIN parents p ON m.id = p.id_enfant`;
      connection.query(query, (error, results, fields) => {
        if (error) {
          reject(error);
        } else {
          const membres = results;
          /*const membres = results.map(membreData => {
            return membreData
          });*/
          cb ({membres:membres});
        }
      });
    });
  }
  
  static findParents(id_enfant) {
    return new Promise((resolve, reject) => {
      const query = 'SELECT * FROM parents WHERE id_enfant = ?';
      const values = [id_enfant];
      connection.query(query, values, (error, results) => {
        if (error) {
          reject(error);
        } else {
          if (results.length > 0) {
            const parents = results[0];
            resolve(parents);
          } else {
            resolve(null);
          }
        }
      });
    });
  }
          
// Méthode pour mettre à jour un membre dans la base de données
static updateMembre(id, prenoms, nom, date_naissance, date_deces, photo, genre) {
  return new Promise((resolve, reject) => {
    const query = 'UPDATE membres SET prenoms = ?, nom = ?, date_naissance = ?, date_deces = ?, photo = ?, genre = ? WHERE id = ?';
    const values = [prenoms, nom, date_naissance, date_deces, photo, genre, id];
    connection.query(query, values, (error, results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results);
      }
    });
  });
}
          
// Méthode pour supprimer un membre de la base de données
  static deleteMembre(membreId) {
    return new Promise((resolve, reject) => {
      const query = 'DELETE FROM membres WHERE id = ?';
      const values = [membreId];
      connection.query(query, values, (error, results) => {
        if (error) {
          reject(error);
        } else {
          resolve(this);
        }
      });
    });
  }
  static parenter(a,b){
    const x=String((a*b)+String(a)[0])
    return x
  }
  static deparenter(x) {
    const xStr = String(x); // Convertir x en chaîne de caractères
    const b = Number(xStr[xStr.length - 1]); // Extraire le dernier chiffre de x comme valeur de b
    const a = Number(xStr.slice(0, xStr.length - 1)) / b; // Extraire le reste de x comme valeur de a et diviser par b
    return {a,b} // Renvoyer les valeurs originales de a et b sous forme d'objet
  }
}

          
module.exports = Membre;

          
          
          
