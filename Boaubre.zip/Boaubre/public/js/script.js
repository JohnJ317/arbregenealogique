const socket = io.connect('http://localhost:3600')
  function previewImage(event) {
    var image = document.getElementById('imagePreview');
    image.src = URL.createObjectURL(event.target.files[0]);
    image.style.display = 'block';
  }

  // Ajouter un écouteur d'événement pour le champ de fichier
  document.getElementById('photoUpload').addEventListener('change', previewImage);



  function deleteMembre(membreId) {
    socket.emit('deleteMembre', membreId);
  }
  // Code client pour écouter l'événement Socket.io de suppression d'un membre
  socket.on('membreSupprime', membreId => {
      window.location.href='/'
  });
 
  function updateMembre(membreId) {

    socket.emit('getMembre', membreId);

  }
  // Fonction pour formater une date au format 'aaaa-mm-jj'
function formatDate(dateStr) {
  // Créer un nouvel objet Date à partir de la chaîne de caractères
  var date = new Date(dateStr);

  // Obtenir les parties de la date
  var day = date.getDate();
  var month = date.getMonth() + 1; // Mois commence à 0, donc on ajoute 1
  var year = date.getFullYear();

  // Ajouter un zéro devant si le jour ou le mois est inférieur à 10
  if (day < 10) {
    day = '0' + day;
  }
  if (month < 10) {
    month = '0' + month;
  }

  // Retourner la date formatée au format 'aaaa-mm-jj'
  return year + '-' + month + '-' + day;
}

socket.on("badphone",function(){
  $(".phonerror").html("numero invalide")
  $(".phonerror").fadeIn()
  $(".phonerror").parent().addClass("error")
  $("#subinscri").attr("onclick","return false")
})
socket.on("bademail",function(){
  $(".emailerror").html("email invalide")
  $(".emailerror").fadeIn()
  $(".emailerror").parent().addClass("error")
})

socket.on("existemailphone",function(){
  $(".phonerror").html("Numero de téléphone déja utilisé")
  $(".phonerror").parent().addClass("error")
  $(".emailerror").html("Adresse email déja utilisée")
  $(".emailerror").parent().addClass("error")
  $("#subinscri").attr("onclick","return false")
  $(".phonerror").fadeIn()
  $(".emailerror").fadeIn()
  
})

socket.on("invalidemail",function(){
  $(".emailerror").html("Adresse email déja utilisée")
  $(".emailerror").fadeIn()
  $(".emailerror").parent().addClass("error")
  $("#subinscri").attr("onclick","return false")
})

socket.on("invalidphone",function(){
  $(".phonerror").html("Numero de téléphone déja utilisé")
  $(".phonerror").fadeIn()
  $(".phonerror").parent().addClass("error")
  $("#subinscri").attr("onclick","return false")
})
socket.on("validemail",function(){
  $(".emailerror").parent().removeClass("error")
  $(".emailerror").fadeOut()
})
socket.on("validphone",function(){
  $(".phonerror").parent().removeClass("error")
  $(".phonerror").fadeOut()
})
socket.on("valid",function(){
  $(".phonerror").parent().removeClass("error")
  $(".emailerror").parent().removeClass("error")
  $("#subinscri").attr("onclick","return true")
  $(".phonerror").fadeOut()
  $(".emailerror").fadeOut()
})

$("#email").blur(function(){
  var phone=$("#phone").val()
  var email=$("#email").val()
  if(email ===""){

  }
  else{
      if(!emailIsValid(email)){
          $(".emailerror").html("email invalide")
          $(".emailerror").fadeIn()
          $(".emailerror").parent().addClass("error")
      }
      else{
          socket.emit('testemail', {phone,email});
      }
  }
})

socket.on("famille",function(data){
  alert(data)
  socket.emit('famille', {data});
})


socket.on("connecte",data => {
  window.location.href = "/"; 
})
socket.on("codinvalid",function(){
  $("#subinscri").attr("onclick","return false")
  $(".errormessage").fadeIn()
  $(".errormessage").parent().addClass("error")
  
})

socket.on("badcode",function(){
  $("#confirm").attr("onclick","return false")
  $(".codemessage").fadeIn()
})
socket.on("goodcode",function(){
  $(".codemessage").fadeOut()
  if($("#confirmpass").val()===$("#newpass").val()){
      $("#confirm").attr("onclick","return true")  
  }
    
})

function session(){
  code=parseInt($("#code").val())
  socket.emit("session",{code})
}

$("#code2").blur(function(){
  code=parseInt($("#code2").val())
  socket.emit("session2",{code})
})

$("#phone").blur(function(){
  var phone=$("#phone").val()
  var email=$("#email").val()
  var debut=phone.slice(0,2)
  
  if(phone!=""){
      if(phone.length!=10 || !["01","05","07"].includes(debut)){
          $(".phonerror").html("numero invalide")
          $(".phonerror").fadeIn()
          $(".phonerror").parent().addClass("error")
      }
      else{
          socket.emit('testphone', {phone,email});
      }
  }  
})
$("#confirmpass").blur(function(){
  if($(this).val()!=$("#newpass").val()){
      $(".passworderror").fadeIn()
      $("#confirm").attr("onclick","return false")
  }
  else{
      $(".passworderror").fadeOut()
      $("#confirm").attr("onclick","return true")
  }
})

function showpassword() {
  var x = $("[name='password']")
  if ($("[name='password']").attr("type") === "password") {
      $("[name='password']").attr("type","text")
  } else {
      $("[name='password']").attr("type","password")
  }
}
socket.on('getMembre', membre => {
    if (membre) {
      $('input[name="id"]').val(membre.id)
      $('input[name="prenoms"]').val(membre.prenoms);
      $('input[name="nom"]').val(membre.nom);
      if(membre.date_naissance){
        $('input[name="date_naissance"]').val(formatDate(membre.date_naissance));
      }
      if(membre.date_deces){
        $('input[name="date_deces"]').val(formatDate(membre.date_deces));
      }
      $('select[name="id_mere"]').val(membre.id_mere);
      $('select[name="id_pere"]').val(membre.id_pere);
      $('select[name="genre"]').val(membre.genre);
      
      // Affichez l'aperçu de l'image du membre s'il y en a une
      if (membre.photo) {
        $('input[name="photo2"]').val(membre.photo);
        $('#imagePreview').attr('src', 'assets/' + membre.photo).show();
      }
      // Affichez le bouton de mise à jour du formulaire
      $('.toggle-form button[type="submit"]').text('Mettre à jour');
      $('.toggle-form').attr("action","/update")
      $('h3').html("Modification")
      $('.ajouter').fadeOut()
      $('.overlay,.toggle-form').fadeIn()
      const element = document.querySelector('.overlay'); // Utiliser querySelector pour obtenir le premier élément correspondant
      element.scrollIntoView(true); // Appeler scrollIntoView sur l'élément obtenu

    }

});


// Récupérer tous les textes générés par EJS
$(".famille").each(function() {
  var texteEJS  = $(this).text();
  var id=$(this).attr("id")
  $(this).before(texteEJS)
  $(this).detach()
});
function recherche(){
  var field = $("#recherche").val()
  if(field!==''){
    socket.emit('recherche',field)
  }
  else{
    $(".result").html('')
  }

}
socket.on('recherche',function(result){
  var content=''
  
  for(let i in result ){
      content=content+"<div class='result-field' onclick='chef("+result[i].id+")' >"+ result[i].prenoms+" "+result[i].nom+"</div>"
  }
  $(".result").html(content)
  
})

// Fonction pour aligner les conjoints à gauche, au centre et à droite
function alignerConjoints() {
  $('.item').each(function() {
    // Obtenir l'attribut 'id' de l'élément en cours de parcours
    var id = $(this).attr('id');
    var i=1
    var html=""
    $('.conjointof_'+id).each(function() {
      if(i===2 && $('.conjoint1').hasClass('conjointof_'+id)){
        html=$('#'+id).nextUntil('.conjoint2').html()
        $("#"+id).before(html)
    }
      // Ajout de classes CSS d'alignement en fonction de l'ID de l'individu associé

      i++
    });
  });

}
var content=""
function createMatrix() {
  // Récupérer tous les éléments de la classe '.item'
  var items = $('.item');

  // Obtenir la taille de la matrice (carrée)
  var matrixSize = items.length;

  // Créer une matrice carrée de taille matrixSize x matrixSize avec des valeurs par défaut de 0
  var matrix = new Array(matrixSize);
  for (var i = 0; i < matrixSize; i++) {
    matrix[i] = new Array(matrixSize).fill(0);
  }

  // Récupérer le premier élément avec un id
  var firstItemId = items.first().attr('id');
  
  var count=0
  // Fonction récursive pour chercher les conjoints et les enfants de chaque enfant
  function recursiveSearch(parentId, row) {
    
    (matrix[row]).push(parentId)
    
    var conjointId = $('.conjoint1.conjointof_' + parentId).attr('id');
    if (conjointId) {
      (matrix[row]).push(conjointId)
      $('.enfant1.parent2_' + conjointId).each(function() {
        var id= $(this).attr('id');
        recursiveSearch(id, row + 1,);
      })
    }

    conjointId = $('.conjoint2.conjointof_' + parentId).attr('id');
    if (conjointId) {
      (matrix[row]).push(conjointId);
      $('.enfant2.parent2_' + conjointId).each(function() {
        var id= $(this).attr('id');
        recursiveSearch(id, row + 1);
      })
    }
    
    if(count<row){
      count=row
    }
    return(row)
  }

  // Appel initial de la recherche récursive avec les enfants de conjoint1 et conjoint2
  recursiveSearch(firstItemId, 0);
  var tab=new Array(count+1).fill([])
  var matrix2=Array(count).fill(0)
  for (var i = 0; i < count+1; i++) {
    var tab2=matrix[i]
    var k=0
    for (j of tab2) {
      if(j!==0){
        tab[k]=j
        content=content+j+","
        k++
      }
    }
    content=content+"/"
  }
  content=content.replace(/,\/+/g, "/").replace(/\/$/, "")

  
}

// Utilisation de la fonction pour créer la matrice
createMatrix();
function creerLignesDivs(chaine) {
  var lignes = chaine.split("/"); // Diviser la chaîne en fonction des "/"
  var matrice = []; // Matrice pour stocker les lignes de divs
  var i, j;

  // Parcourir chaque ligne
  for (i = 0; i < lignes.length; i++) {
    var divs = lignes[i].split(","); // Diviser la ligne en fonction des ","
    var ligneDivs = []; // Ligne de divs pour cette itération

    // Parcourir chaque div dans la ligne
    for (j = 0; j < divs.length; j++) {
      var id = divs[j]; // ID du div
      var div = $("#"+id);
      $("#"+id).hide()
      
      ligneDivs.push(div); // Ajouter le div à la ligne de divs
    }

    matrice.push(ligneDivs); // Ajouter la ligne de divs à la matrice
  }

  return matrice; // Retourner la matrice de divs générée
}

var matriceDivs = creerLignesDivs(content);
function compte(nb){
  var tab=["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
    "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen",
    "eighteen", "nineteen", "twenty", "twenty-one", "twenty-two", "twenty-three",
    "twenty-four", "twenty-five", "twenty-six", "twenty-seven", "twenty-eight",
    "twenty-nine", "thirty"
  ];
  return tab[nb]
}

function addConjoint() {
  // Récupérer tous les éléments avec la classe "conjoint"
  $(".conjoint").each(function() {
    // Récupérer l'id de l'époux à partir de la classe "conjointof_x"
    var idEpoux = $(this).attr("class").match(/conjointof_(\d+)/)[1];
    // Ajouter la classe "conjointof_y" à l'élément ayant l'id "idEpoux"
    $("#"+idEpoux).addClass("conjointof_"+$(this).attr("id"));
    $("#"+idEpoux).addClass("lignee");
  });
}

addConjoint()

function arbre(id, range) {
  $("h2 i").remove()
  var idParent = $("#"+id).attr("class").match(/parent1_(\d+)/);
  if(idParent){
      var chef=idParent[1]
      $("h2").append('<i class="ui icon circle chevron up" onclick="chef('+chef+')"></i>')
  }
  // Construire le sélecteur de classe pour les conjoints de l'individu
  var classeConjointe = ".conjointof_" + id;
  var parent = $('#' + id);
  $(".arbre .ligne1").append(parent)
  if ($(classeConjointe).length > 0) {
    var nbConjoints = $(classeConjointe).length;
    var conjointeAffichee = $(classeConjointe + ":eq(" + range + ")");
    var idConjoint = $(conjointeAffichee).attr("id");

    // Masquer les autres conjoints
    $(classeConjointe).hide();
    $(conjointeAffichee).show();
    $(".arbre .ligne1").append($("#" + idConjoint));
    if (nbConjoints > 1) {
      $(".arbre .ligne1 .conjoint").append('<i class="ui icon caret right" onclick="suivantConjoint('+id+')"></i>')
    }

    var enfants = $(".parent1_" + id + ".parent2_" + idConjoint);
    if(enfants.length===0){
      enfants = $(".parent1_" + idConjoint + ".parent2_" + id);
    }
    var nbEnfants = enfants.length;
    var taille = 0;
    if (nbEnfants > 3) { taille = 3 }
    $(".arbre .ligne2").addClass(compte(taille))
    if (nbEnfants > 3) {
      $(".arbre .ligne2").append('<i class="ui icon chevron circle right" onclick="suivantEnfant('+id+','+idConjoint+')"></i>');
    }
    if (nbEnfants > 0) {
      var i = 0;
      var last=0
      enfants.each(function() {
        if (i < 3) {
          var enfant = $(this);
          var conjoint = $(".conjointof_" + enfant.attr("id"));
          var enfantHTML = $("<div class='ui two grid column'></div>");
          enfantHTML.append(enfant);
          if (conjoint.length > 0) {
            // Masquer les autres co-épouses
            conjoint.hide();
            if (conjoint.length > 1) {
              enfantHTML.append('<i class="ui icon caret  right" onclick="suivantConjoint('+enfant.attr("id")+')"></i>')
            }
            enfantHTML.append(conjoint.first());
          }
          $(".arbre .ligne2").append(enfantHTML);
          conjoint = conjoint.first();
          i++;
          if($(".couple"+i).length === 0){
            $(".arbre .ligne3").append('<div class="ui couple'+i+' grid column"></div>');
          }
          if (conjoint.attr("id")) {
            var petitsenfants = $(".parent1_" + enfant.attr("id") + ".parent2_" + conjoint.attr("id"));
            taille = petitsenfants.length;
            if (petitsenfants.length > 3) { taille = 3 }
            
            $(".couple" + i).addClass(compte(taille));
            var j=0
            petitsenfants.each(function() {
              if(j<3){
                $(".couple" + i).append($(this));
                last=$(this).attr("id")
                last=$(".parent1_"+last).attr("id")||$(".parent2_"+last).attr("id")
                
              }
              j++
            });
            if(petitsenfants.length>3){
              $(".couple"+i).append('<i class="ui icon circle arrow  right" onclick="suivantPtitEnfant('+enfant.attr("id")+','+conjoint.attr("id")+','+i+')"></i>')
            }
          }

        }
      });
      if(last){
        var chef=$(".ligne2 .item.lignee").first().attr("id");
        $("h2").append('<i class="ui icon circle chevron down" onclick="chef('+chef+')"></i>')
      }
    }
  }
  $('.arbre .item').fadeIn();
}


// Afficher le conjoint suivant
function suivantConjoint(id) {
  // Récupérer le nombre de conjoints de l'individu
  var nbConjoints = $(".conjointof_" + id).length;
  // Récupérer l'index du conjoint affiché actuellement
  var conjointAffiche = $(".conjointof_" + id + ":visible");
  var indexConjoint = $(".conjointof_" + id).index(conjointAffiche);
  // Si on est à la dernière conjointe, afficher la première conjointe
  if (indexConjoint === nbConjoints - 1) {
    indexConjoint = 0;
  } else { // Sinon, afficher la conjointe suivante
    indexConjoint++;
  }
  var membresActif=$('.arbre .item')

  $('.arbre .ligne1').empty()
  $(".ligne2").empty();
  $(".arbre .ligne2").removeClass('one two three four');
  $(".couple1,.couple2,.couple3").empty();
  $(".couple1,.couple2,.couple3").removeClass('one two three four');
  // Afficher le conjoint correspondant
  membresActif.each(function(){
    $('.list').append(this)
  })
  arbre(id, indexConjoint);

}

function suivantEnfant(parent1, parent2){
  $("h2 i").remove()
  var idParent = $("#"+parent1).attr("class").match(/parent1_(\d+)/);
  if(idParent){
      var chef=idParent[1]
      $("h2").append('<i class="ui icon circle chevron up" onclick="chef('+chef+')"></i>')
  }
  var enfants= $(".parent1_"+parent1+".parent2_"+parent2)
  if(enfants.length===0){
    enfants = $(".parent1_" + parent2 + ".parent2_" + parent1);
  }
  var conjointsEnfant=[]
  enfants.each(function(){
    var id=$(this).attr("id")
    var conjoint=$(".conjointof_"+id+":visible")
    conjointsEnfant.push(conjoint)
  })
  var petitsenfants= $(".ligne3 .item")
  $(".ligne2").empty()
  $(".couple1, .couple2, .couple3").empty()
  for (var c of conjointsEnfant){
    $('.list').append(c)
  }
  enfants.each(function(){
    $('.list').append(this)
  })

  petitsenfants.each(function(){
    $('.list').append(this)
  })
  var nbEnfants=enfants.length
  if (nbEnfants > 3) {
    $(".arbre .ligne2").append('<i class="ui icon chevron circle right" onclick="suivantEnfant('+parent1+','+parent2+')"></i>');
  }
  if (nbEnfants > 0) {
    var i = 0;
    var last=0
    enfants.each(function() {
      if (i < 3) {
        var enfant = $(this);
        var conjoint = $(".conjointof_" + enfant.attr("id"));
        var enfantHTML = $("<div class='ui two grid column'></div>");
        enfantHTML.append(enfant);
        if (conjoint.length > 0) {
          // Masquer les autres co-épouses
          conjoint.hide();
          if (conjoint.length > 1) {
            enfantHTML.append('<i class="ui icon caret  right" onclick="suivantConjoint('+enfant.attr("id")+')"></i>')
          }
          enfantHTML.append(conjoint.first());
        }
        
        $(".arbre .ligne2").append(enfantHTML);
        conjoint = conjoint.first();
        i++;
        if($(".couple"+i).length === 0){
          $(".arbre .ligne3").append('<div class="ui couple'+i+' grid column"></div>');
        }
        if (conjoint.attr("id")) {
          var petitsenfants = $(".parent1_" + enfant.attr("id") + ".parent2_" + conjoint.attr("id"));
          taille = petitsenfants.length;
          if (petitsenfants.length > 3) { taille = 3 }
          $(".couple" + i).addClass(compte(taille));
          var j=0
          petitsenfants.each(function() {
            if(j<3){
              $(".couple" + i).append($(this));
              last=$(this).attr("id")
              last=$(".parent1_"+last).attr("id")||$(".parent2_"+last).attr("id")
            }
            j++
          });
          if(petitsenfants.length>3){
            $(".couple"+i).append('<i class="ui icon circle arrow  right" onclick="suivantPtitEnfant('+enfant.attr("id")+','+conjoint.attr("id")+','+i+')"></i>')
          }
        }

      }
    });
    if(last){
      var chef=$(".ligne2 .item.lignee").first().attr("id");
      $("h2").append('<i class="ui icon circle chevron down" onclick="chef('+chef+')"></i>')
    }
  }
  $('.arbre .ligne2 .item, .arbre .ligne3 .item').fadeIn()
}

function suivantPtitEnfant(parent1, parent2, range){
  var petitsenfants= $(".couple"+range+" .item")
  $(".couple"+range).empty()
  petitsenfants.each(function(){
    $('.list').append(this)
  })
  petitsenfants= $(".parent1_"+parent1+".parent2_"+parent2)
  var j=0
  petitsenfants.each(function() {
    if(j<3){
      $(".couple" + range).append(this);
    }
    j++
  });
  if(petitsenfants.length>3){
    $(".couple"+range).append('<i class="ui icon circle arrow  right" onclick="suivantPtitEnfant('+parent1+','+parent2+','+range+')"></i>')
  }
  $(".couple"+range+" .item").fadeIn()
}

function chef(id){
  $("#chef").val(id)
  $("#cheform").submit()
}


$(".item").hover(function(){
  var id = $(this).attr("id")
  $("#"+id+" i").fadeIn()
})
$(".item").mouseleave(function(){
  var id = $(this).attr("id")
  $("#"+id+" i:not(.caret)").fadeOut()
})
